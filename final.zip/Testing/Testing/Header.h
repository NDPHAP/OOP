#pragma once
#pragma once
#include <iostream>
#include <windows.h>
#include <string>
#include <string.h>
#include<conio.h>
#include <math.h>
#include <vector>
#include <fstream>
#include <time.h>
#include <random>
#include <thread>
#include<time.h>
using namespace std;

#include "Console.h"
#include "CPEOPLE.h"
#include "CGAME.h"
#include "OBSTRUCTOR.h"
#include "MENU.h"
#include "EFFECT.h"


#define y1 = 8;
#define y2 = 15;
#define y3 = 23;
#define y4 = 32;

#define maxX_console 180;
#define maxY_console 45;

#define maxX_game 144;
#define maxY_game 45;