#include "Console.h"

class TRAFFIC : public Console
{
public:
    void draw(int a);
    int getPausekey();
    int pause_key;
private:

};

